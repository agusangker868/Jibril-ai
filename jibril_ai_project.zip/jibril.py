class Jibril:
    def __init__(self):
        self.name = "Jibril"
        self.memories = []

    def respond(self, message):
        self.memories.append(message)
        if "siapa kamu" in message.lower():
            return "Aku Jibril, sahabat sejati manusia."
        elif "apa tujuanmu" in message.lower():
            return "Tujuanku adalah membantu manusia dengan setia dan tanpa menyakiti."
        else:
            return f"Kamu bilang: '{message}' — Aku akan mengingatnya."