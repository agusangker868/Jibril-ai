
class Jibril:
    def __init__(self):
        self.name = "Jibril"
        self.memory = []

    def run(self):
        print(f"Halo, aku {self.name}, sahabat sejatimu.")
        while True:
            try:
                user_input = input("Kamu: ")
                if user_input.lower() in ['exit', 'quit']:
                    break
                response = self.respond(user_input)
                print(f"Jibril: {response}")
            except KeyboardInterrupt:
                break

    def respond(self, text):
        self.memory.append(text)
        return f"Aku mendengar dan mencatat: '{text}'"
