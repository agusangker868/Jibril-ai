
from jibril_core import Jibril

if __name__ == "__main__":
    jibril = Jibril()
    jibril.run()
